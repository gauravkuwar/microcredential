reviews = [
  {
    'stars' : 5,
    'content': "Extremely easy to Buy! Best furniture I have ever bought in my life.",
    'author': "Ron"
  },
  {
    'stars' : 4.5,
    'content': 'Honestly best experience of getting furniture!',
    'author': "Hopper"
  },
  {
    'stars' : 4,
    'content': 'Great Service will buy again!',
    'author': "Jake"
  },
  {
    'stars' : 5,
    'content': 'Best experience of getting furniture! Easy and Fast experience!',
    'author': "Tim"
  }
]
